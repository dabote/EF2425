
/**
 * Write a description of class Steuerung here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Steuerung
{
    /**
     * Constructor for objects of class Steuerung
     */
    public Steuerung()
    {

    }

    public void testeSchiffe()
    {
        Schiff erstesSchiff;
        Schiff zweitesSchiff;
        
        erstesSchiff = new Schiff("OceanDrive", 15, 30 );
        zweitesSchiff = new Schiff("RiverDrive", 5, 10 );
    }
}
